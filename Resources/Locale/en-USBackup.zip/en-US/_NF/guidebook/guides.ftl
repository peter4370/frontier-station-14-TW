# Base entries
guide-entry-nf14 = Frontier Guide
guide-entry-bank = NT Galactic Bank
guide-entry-piloting = Piloting
guide-entry-startinggear = Starting Equipment
guide-entry-hiring = Hiring Crew
guide-entry-interviews = Interviews
guide-entry-expeditions = Expeditions
guide-entry-sector-topology = Sector Topology
guide-entry-cargo-hauling = Cargo Hauling
guide-entry-shipyard = Shipyard
guide-entry-shipyard-civilian = Civilian ships
guide-entry-shipyard-staff = Frontier Staff ships
guide-entry-shipyard-medical = Medical ships
guide-entry-shipyard-expedition = Expedition ships
guide-entry-shipyard-nfsd = NFSD ships
guide-entry-shipyard-scrap = Scrap ships
guide-entry-frontier-rules = Server Rules
guide-entry-frontier-definitions = Definitions
guide-entry-preflightchecklist = Preflight Checklist

# Engineering entries
guide-entry-offshore-gas-mining = Offshore Gas Mining

# Security entries
guide-entry-nfsd-smuggling = Smuggling

# Medical entries
guide-entry-medical-bounties = Medical Bounties
guide-entry-medical-doc = Director of Care

# Reference entries
guide-entry-medicalrecipes = Medical Recipes
guide-entry-weapons-ranged-archetypes = Ranged Weapon Archetypes
guide-entry-weapons-color-codes-ammo = Ammunition Color Codes

# Expedition faction entries
guide-entry-expedition-aberrant-flesh = Aberrant Flesh
guide-entry-expedition-argocytes = Argocytes
guide-entry-expedition-blood-cultists = Blood Cultists
guide-entry-expedition-carps = Carps
guide-entry-expedition-dinosaurs = Dinosaurs
guide-entry-expedition-explorers = Explorers
guide-entry-expedition-mercenaries = Mercenaries
guide-entry-expedition-gangers = Punks
guide-entry-expedition-silicons = Rogue Silicons
guide-entry-expedition-syndicate-naval-forces = Syndicate Naval Forces
guide-entry-expedition-xenos = Xenos

# Civilian Shipyard entries
guide-entry-shipyard-adder = Adder
guide-entry-shipyard-ambition = Ambition
guide-entry-shipyard-backpacker = Backpacker
guide-entry-shipyard-balena = Balena
guide-entry-shipyard-barge = Barge
guide-entry-shipyard-baroness = Baroness
guide-entry-shipyard-bocadillo = Bocadillo
guide-entry-shipyard-bodkin = Bodkin
guide-entry-shipyard-bookworm = Bookworm
guide-entry-shipyard-bulker = Bulker
guide-entry-shipyard-camper = Camper
guide-entry-shipyard-ceres = Ceres
guide-entry-shipyard-chisel = Chisel
guide-entry-shipyard-coffeehouse = Coffeehouse
guide-entry-shipyard-comet = Comet
guide-entry-shipyard-courier = Courier
guide-entry-shipyard-copperhead = Copperhead
guide-entry-shipyard-crescent = Crescent
guide-entry-shipyard-crossroads = Crossroads
guide-entry-shipyard-dragoon = Dragoon
guide-entry-shipyard-firefighter = Firefighter
guide-entry-shipyard-garden = Garden
guide-entry-shipyard-gasbender = Gasbender
guide-entry-shipyard-gaslight = Gaslight
guide-entry-shipyard-hammer = Hammer
guide-entry-shipyard-hauler = Hauler
guide-entry-shipyard-honker = Honker
guide-entry-shipyard-investigator = Investigator
guide-entry-shipyard-izakaya = Izakaya
guide-entry-shipyard-jackrabbit = Jackrabbit
guide-entry-shipyard-kestrel = Kestrel
guide-entry-shipyard-kilderkin = Kilderkin
guide-entry-shipyard-lantern-mk2 = Lantern Mk2
guide-entry-shipyard-stringer = Stringer
guide-entry-shipyard-stronghold = Stronghold
guide-entry-shipyard-liquidator = Liquidator
guide-entry-shipyard-loader = Loader
guide-entry-shipyard-lyrae = Lyrae
guide-entry-shipyard-mccargo = McCargo
guide-entry-shipyard-mcdelivery = McDelivery
guide-entry-shipyard-nightlight = Nightlight
guide-entry-shipyard-nook = Nook
guide-entry-shipyard-phoenix = Phoenix
guide-entry-shipyard-placebo = Placebo
guide-entry-shipyard-prospector = Prospector
guide-entry-shipyard-pulsar = Pulsar
guide-entry-shipyard-retort = Retort
guide-entry-shipyard-skipper = Skipper
guide-entry-shipyard-spectre = Spectre
guide-entry-shipyard-stellaris = Stellaris
guide-entry-shipyard-surveyor = Surveyor
guide-entry-shipyard-vagabond = Vagabond

# Medical Shipyard entries
guide-entry-shipyard-akupara = Akupara
guide-entry-shipyard-apothecary = Apothecary
guide-entry-shipyard-caladrius = Caladrius
guide-entry-shipyard-druid = Druid
guide-entry-shipyard-eagle = Eagle
guide-entry-shipyard-searchlight = Searchlight
guide-entry-shipyard-spirit = Spirit
guide-entry-shipyard-stasis = Stasis
guide-entry-shipyard-tyne = Tyne
guide-entry-shipyard-vitalis = Vitalis
guide-entry-shipyard-voltage = Voltage

# Frontier Staff Shipyard entries
guide-entry-shipyard-broom = Broom
guide-entry-shipyard-harbormaster = Harbormaster
guide-entry-shipyard-hound = Hound

# Expedition Shipyard entries
guide-entry-shipyard-aegis = Aegis
guide-entry-shipyard-anchor = Anchor
guide-entry-shipyard-brigand = Brigand
guide-entry-shipyard-charon = Charon
guide-entry-shipyard-dendron = Dendron
guide-entry-shipyard-dove = Dove
guide-entry-shipyard-dragonfly = Dragonfly
guide-entry-shipyard-pathfinder = Pathfinder

# Scrap Shipyard entries
guide-entry-shipyard-construct = Construct
guide-entry-shipyard-geode = Geode
guide-entry-shipyard-rusty = Rusty
guide-entry-shipyard-tide = Tide

# NFSD Shipyard entries
guide-entry-shipyard-broadhead = Broadhead
guide-entry-shipyard-cleric = Cleric
guide-entry-shipyard-empress = Empress
guide-entry-shipyard-fighter = Fighter
guide-entry-shipyard-heimdall = Heimdall
guide-entry-shipyard-hospitaller = Hospitaller
guide-entry-shipyard-hypnos = Hypnos
guide-entry-shipyard-paladin = Paladin
guide-entry-shipyard-prowler = Prowler
guide-entry-shipyard-rogue = Rogue
guide-entry-shipyard-templar = Templar
guide-entry-shipyard-wasp = Wasp

# Rules entries
guide-entry-frontier-rule-zero-tolerance = Zero Tolerance
guide-entry-frontier-rule-1 = 1. Community
guide-entry-frontier-rule-2 = 2. IC Info
guide-entry-frontier-rule-3 = 3. Escalation
guide-entry-frontier-rule-4 = 4. Chat
guide-entry-frontier-rule-5 = 5. Roleplay
guide-entry-frontier-rule-6 = 6. Safezone
guide-entry-frontier-rule-7 = 7. Antagonism
guide-entry-frontier-rule-8 = 8. PVP
guide-entry-frontier-rule-9 = 9. Piracy
guide-entry-frontier-rule-10 = 10. Crimes
guide-entry-frontier-rule-11 = 11. Silicons
guide-entry-frontier-rule-12 = 12. Security
guide-entry-frontier-rule-13 = 13. Command
# Unlisted entries
nf-guide-blood-cult-staves = Blood Cult Staff Activation Guide
nf-guide-wizard-federation-staves = Wizard Staff Activation Guide
