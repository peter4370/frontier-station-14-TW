# Frontier
job-name-bailiff = Bailiff
job-name-brigmedic = Brigmedic
job-name-cadet-nf = Cadet
job-name-contractor = Contractor
job-name-contractor-interview = Contractor Applicant
job-name-deputy = Deputy
job-name-nf-detective = Detective
job-name-doc = Director of Care
job-name-ertmailcarrier = ERT Mail Carrier
job-name-mail-carrier = Mail Carrier
job-name-guard = Prison Guard
job-name-mercenary = Mercenary
job-name-mercenary-interview = Mercenary Applicant
job-name-pal = Public Affairs Liaison
job-name-pilot = Pilot
job-name-pilot-interview = Pilot Applicant
job-name-nf-pirate = Pirate
job-name-nf-pirate-interview = Pirate Applicant
job-name-nf-pirate-captain = Pirate Captain
job-name-nf-pirate-first-mate = Pirate First Mate
job-name-plant-manager = Plant Manager
job-name-plant-technician = Plant Technician
job-name-security-guard = Security Guard
job-name-sheriff = Sheriff
job-name-stc = Station Traffic Controller
job-name-sr = Station Representative
job-name-valet = Valet

# Job titles
job-title-ert-mail-carrier = ERT Mail Carrier

# Role timers - Keep these alphabetical, please
JobContractorInterview = Contractor Applicant
JobERTMailCarrier = ERT Mail Carrier
JobMercenary = Mercenary
JobMercenaryInterview = Mercenary Applicant
JobPilot = Pilot
JobPilotInterview = Pilot Applicant
JobPirate = Pirate
JobPirateInterview = Pirate Applicant
JobPirateCaptain = Pirate Captain
JobPirateFirstMate = Pirate First Mate
JobPlantManager = Plant Manager
JobPlantTechnician = Plant Technician
JobPublicAffairsLiaison = Public Affairs Liaison
JobSecurityGuard = Security Guard
JobSTC = Station Traffic Controller

# Upstream Removed
job-name-senior-engineer = Senior Engineer
job-name-senior-officer = Sergeant
job-name-senior-physician = Senior Physician
job-name-senior-researcher = Senior Researcher

JobSeniorEngineer = Senior Engineer
JobSeniorOfficer = Sergeant
JobSeniorPhysician = Senior Physician
JobSeniorResearcher = Senior Researcher
