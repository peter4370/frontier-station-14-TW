goldleaf = Gold Leaf
