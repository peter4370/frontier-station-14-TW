construction-category-goblin = Goblin
