marking-MothAntennasNone = None
